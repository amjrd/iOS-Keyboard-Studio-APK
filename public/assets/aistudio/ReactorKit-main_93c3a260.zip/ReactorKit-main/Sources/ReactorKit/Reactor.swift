//
//  Reactor.swift
//  ReactorKit
//
//  Created by Suyeol Jeon on 06/04/2017.
//  Copyright © 2017 Suyeol Jeon. All rights reserved.
//

import Foundation

import RxSwift
@preconcurrency import WeakMapTable

/// A Reactor is an UI-independent layer which manages the state of a view. The foremost role of a
/// reactor is to separate control flow from a view. Every view has its corresponding reactor and
/// delegates all logic to its reactor. A reactor has no dependency to a view, so it can be easily
/// tested.
public protocol Reactor: AnyObject {
  /// An action represents user actions.
  associatedtype Action

  /// A mutation represents state changes.
  associatedtype Mutation = Action

  /// A State represents the current state of a view.
  associatedtype State

  /// The action from the view. Bind user inputs to this subject.
  ///
  /// **Action dispatch contract**: callers of `action.onNext(_:)` are
  /// expected to dispatch from the main thread. This guarantees actions
  /// are serialized into the pipeline from a single thread. The same
  /// rule applies to any external stream merged inside
  /// `transform(action:)` — apply `.observe(on: MainScheduler.instance)`
  /// to it before the merge. In DEBUG builds an `os_log` fault is
  /// emitted when an action reaches `mutate(_:)` off the main thread.
  ///
  /// **Threading**: the pipeline does not reschedule. `transform(action:)`,
  /// `mutate(_:)`, `transform(mutation:)`, `reduce(_:_:)`,
  /// `transform(state:)`, and state subscribers all run on whatever
  /// thread the upstream emits on. If `mutate(_:)` returns an observable
  /// that emits from a background thread, apply `.observe(on:)`
  /// explicitly to hop back onto the thread your consumers expect.
  var action: ActionSubject<Action> { get }

  /// The initial state.
  var initialState: State { get }

  /// The current state. This value is changed just after the state stream emits a new state.
  var currentState: State { get }

  /// The state stream. Use this observable to observe the state changes.
  var state: Observable<State> { get }

  /// Transforms the action. Use this function to combine with other observables. This method is
  /// called once before the state stream is created.
  func transform(action: Observable<Action>) -> Observable<Action>

  /// Commits mutation from the action. This is the best place to perform side-effects such as
  /// async tasks.
  func mutate(action: Action) -> Observable<Mutation>

  /// Transforms the mutation stream. Implement this method to transform or combine with other
  /// observables. This method is called once before the state stream is created.
  func transform(mutation: Observable<Mutation>) -> Observable<Mutation>

  /// Generates a new state with the previous state and the action. It should be purely functional
  /// so it should not perform any side-effects here. This method is called every time when the
  /// mutation is committed.
  func reduce(state: State, mutation: Mutation) -> State

  /// Transforms the state stream. Use this function to perform side-effects such as logging. This
  /// method is called once after the state stream is created.
  func transform(state: Observable<State>) -> Observable<State>
}


// MARK: - Map Tables

private typealias AnyReactor = AnyObject

private enum MapTables {
  static let streams = WeakMapTable<AnyReactor, AnyObject>()
  static let currentState = WeakMapTable<AnyReactor, Any>()
  static let disposeBag = WeakMapTable<AnyReactor, DisposeBag>()
  static let isStubEnabled = WeakMapTable<AnyReactor, Bool>()
  static let stub = WeakMapTable<AnyReactor, AnyObject>()
}


// MARK: - ReactorStreams

private struct ReactorStreams<Action, State> {
  let action: ActionSubject<Action>
  let state: Observable<State>
}

// MARK: - Default Implementations

extension Reactor {
  private var streams: ReactorStreams<Action, State> {
    if isStubEnabled {
      return ReactorStreams(action: stub.action, state: stub.state.asObservable())
    } else {
      return MapTables.streams.forceCastedValue(forKey: self, default: createReactorStreams())
    }
  }

  public var action: ActionSubject<Action> {
    streams.action
  }

  public internal(set) var currentState: State {
    get { MapTables.currentState.forceCastedValue(forKey: self, default: initialState) }
    set { MapTables.currentState.setValue(newValue, forKey: self) }
  }

  public var state: Observable<State> {
    streams.state
  }

  fileprivate var disposeBag: DisposeBag {
    MapTables.disposeBag.value(forKey: self, default: DisposeBag())
  }

  private func createReactorStreams() -> ReactorStreams<Action, State> {
    let actionSubject = ActionSubject<Action>()
    // Trampoline serialization on the current thread. Internal reentrancy-safety
    // mechanism — not a configurable scheduler. Actions dispatched from inside
    // reduce or a state subscriber are queued and processed after the current
    // emission completes. Thread placement remains the caller's responsibility
    // (see action property docs).
    let action = actionSubject.asObservable().observe(on: CurrentThreadScheduler.instance)
    let baseTransformedAction = transform(action: action)
    #if DEBUG
    let transformedAction = baseTransformedAction.do(onNext: { [weak self] _ in
      self?._checkActionDispatchContext()
    })
    #else
    let transformedAction = baseTransformedAction
    #endif
    let mutation = transformedAction
      .flatMap { [weak self] action -> Observable<Mutation> in
        guard let self = self else { return .empty() }
        return self.mutate(action: action).catch { _ in .empty() }
      }
    let transformedMutation = transform(mutation: mutation)
    let state = transformedMutation
      .scan(initialState) { [weak self] state, mutation -> State in
        guard let self = self else { return state }
        return self.reduce(state: state, mutation: mutation)
      }
      .catch { _ in .empty() }
      .startWith(initialState)
    let transformedState = transform(state: state)
      .do(onNext: { [weak self] state in
        self?.currentState = state
      })
      .replay(1)
    transformedState.connect().disposed(by: disposeBag)
    return ReactorStreams(action: actionSubject, state: transformedState)
  }

  #if DEBUG
  /// DEBUG-only check that actions reach `mutate(_:)` from the main thread.
  /// Attached after `transform(action:)` so external streams merged inside
  /// `transform(action:)` are also covered. The contract exists to
  /// serialize action entry into the pipeline — see the `action` property
  /// documentation.
  fileprivate func _checkActionDispatchContext() {
    guard !Thread.isMainThread else { return }
    _runtimeWarning(
      "\(type(of: self)) received an action from a non-main thread. "
        + "Dispatch from the main thread (or hop merged streams in "
        + "transform(action:) onto main) to keep action entry serialized."
    )
  }
  #endif

  public func transform(action: Observable<Action>) -> Observable<Action> {
    action
  }

  public func mutate(action: Action) -> Observable<Mutation> {
    .empty()
  }

  public func transform(mutation: Observable<Mutation>) -> Observable<Mutation> {
    mutation
  }

  public func reduce(state: State, mutation: Mutation) -> State {
    state
  }

  public func transform(state: Observable<State>) -> Observable<State> {
    state
  }
}

extension Reactor where Action == Mutation {
  public func mutate(action: Action) -> Observable<Mutation> {
    .just(action)
  }
}


// MARK: - Stub

extension Reactor {
  public var isStubEnabled: Bool {
    get { MapTables.isStubEnabled.value(forKey: self, default: false) }
    set { MapTables.isStubEnabled.setValue(newValue, forKey: self) }
  }

  public var stub: Stub<Self> {
    MapTables.stub.forceCastedValue(forKey: self, default: .init(reactor: self, disposeBag: disposeBag))
  }
}
